#!/usr/bin/env bash
# Move a rsyslog file aside when it hits the configured size, then reopen.
set -euo pipefail

file="${1:?usage: rotate-rsyslog-file.sh /path/to/logfile}"
keep="${LUMI_SYSLOG_ROTATE_KEEP:-3}"
rsyslog_rotate="${RSYSLOG_ROTATE_HELPER:-/usr/lib/rsyslog/rsyslog-rotate}"

[[ -f "${file}" ]] || exit 0

ts="$(date +%Y%m%d-%H%M%S)"
mv "${file}" "${file}.${ts}"

if [[ -x "${rsyslog_rotate}" ]]; then
	"${rsyslog_rotate}"
else
	systemctl kill -s HUP rsyslog.service 2>/dev/null || true
fi

# Keep the newest N archives; delete the rest.
mapfile -t archives < <(ls -1t "${file}".* 2>/dev/null || true)
if (( ${#archives[@]} > keep )); then
	printf '%s\n' "${archives[@]:keep}" | xargs -r rm -f
fi
