#!/usr/bin/env bash
# Shared progress UI for package-OTA factory / services pack scripts.
#
# Source this file (do not execute). Byte bars need python3; without it the
# helpers fall back to plain tar/cp so pack/install still succeed.
#
#   lumi_progress_begin TOTAL # optional step counter
#   lumi_progress_step LABEL
#   lumi_progress_end
#   lumi_progress_cp_tree SRC DEST [LABEL]
#   lumi_pack_tar_xz OUTFILE LABEL CWD [MEMBER...]

[[ -n "${_LUMI_PACK_PROGRESS_LOADED:-}" ]] && return 0
_LUMI_PACK_PROGRESS_LOADED=1

_LUMI_PROGRESS_TOTAL=0
_LUMI_PROGRESS_CUR=0
_LUMI_PROGRESS_TITLE=""

_lumi_progress_have_python() {
	command -v python3 >/dev/null 2>&1
}

# Clear an in-place stderr bar so later errors are not overwritten.
_lumi_progress_clear_line() {
	if [[ -t 2 ]]; then
		printf '\r\033[K' >&2
	fi
}

_lumi_progress_bar_line() {
	local cur="$1" total="$2" label="$3"
	local width=28 filled empty pct i bar
	if [[ "${total}" -le 0 ]]; then
		pct=0
	else
		pct=$((cur * 100 / total))
		[[ "${pct}" -gt 100 ]] && pct=100
	fi
	filled=$((pct * width / 100))
	empty=$((width - filled))
	bar=""
	for ((i = 0; i < filled; i++)); do bar+="#"; done
	for ((i = 0; i < empty; i++)); do bar+="-"; done
	# Always end with newline: in-place \r bars hide die()/shell errors on TTY.
	printf '[%s] %3d%% (%s/%s) %s\n' \
		"${bar}" "${pct}" "${cur}" "${total}" "${label}" >&2
}

# Byte-stream progress filter: stdin -> stdout, bar on stderr.
# Must use python3 -c (not a stdin heredoc) so the pipe stays on stdin.
# EPIPE/BrokenPipe is silent: downstream owns the real failure under pipefail.
# Args: expected_bytes label
_lumi_progress_bytes_filter() {
	local expected="$1" label="$2"
	python3 -u -c '
import sys
expected = max(0, int(sys.argv[1]))
label = sys.argv[2]
width = 28
done = 0
tty = sys.stderr.isatty()
last_pct = -1

def render(force=False):
    global last_pct
    if expected <= 0:
        pct = 0
    else:
        pct = min(100, done * 100 // expected)
    if not force and pct == last_pct and done < expected:
        return
    # Non-TTY logs: only emit on 5% boundaries (plus first/last).
    if not tty and not force and pct != 0 and pct != 100 and (pct // 5) == (last_pct // 5):
        return
    last_pct = pct
    filled = pct * width // 100
    bar = "#" * filled + "-" * (width - filled)
    mb = done / (1024 * 1024)
    if expected > 0:
        total_mb = expected / (1024 * 1024)
        body = "[%s] %3d%% %.1f/%.1fMB %s" % (bar, pct, mb, total_mb, label)
    else:
        body = "[%s] %.1fMB %s" % (bar, mb, label)
    if tty:
        sys.stderr.write("\r\033[K" + body)
    else:
        sys.stderr.write(body + "\n")
    sys.stderr.flush()

def finish_line():
    if tty:
        sys.stderr.write("\n")
        sys.stderr.flush()

stdin = sys.stdin.buffer
stdout = sys.stdout.buffer
try:
    while True:
        chunk = stdin.read(1 << 16)
        if not chunk:
            break
        stdout.write(chunk)
        done += len(chunk)
        render()
    stdout.flush()
    render(force=True)
    finish_line()
except BrokenPipeError:
    finish_line()
    # Quiet exit: rightmost failed stage (xz/tar) reports via pipefail.
    sys.exit(0)
except KeyboardInterrupt:
    finish_line()
    sys.exit(130)
' "${expected}" "${label}"
}

lumi_progress_begin() {
	_LUMI_PROGRESS_TOTAL="${1:-0}"
	_LUMI_PROGRESS_CUR=0
	_LUMI_PROGRESS_TITLE="${2:-}"
	if [[ -n "${_LUMI_PROGRESS_TITLE}" ]]; then
		echo "=== ${_LUMI_PROGRESS_TITLE} (${_LUMI_PROGRESS_TOTAL} steps) ===" >&2
	fi
}

lumi_progress_step() {
	local label="${1:-}"
	_LUMI_PROGRESS_CUR=$((_LUMI_PROGRESS_CUR + 1))
	if [[ "${_LUMI_PROGRESS_TOTAL}" -gt 0 ]]; then
		_lumi_progress_bar_line "${_LUMI_PROGRESS_CUR}" "${_LUMI_PROGRESS_TOTAL}" "${label}"
	else
		echo "→ ${label}" >&2
	fi
}

lumi_progress_end() {
	_lumi_progress_clear_line
	if [[ "${_LUMI_PROGRESS_TOTAL}" -gt 0 && "${_LUMI_PROGRESS_CUR}" -lt "${_LUMI_PROGRESS_TOTAL}" ]]; then
		_lumi_progress_bar_line "${_LUMI_PROGRESS_TOTAL}" "${_LUMI_PROGRESS_TOTAL}" "done"
	fi
	_LUMI_PROGRESS_TOTAL=0
	_LUMI_PROGRESS_CUR=0
	_LUMI_PROGRESS_TITLE=""
}

# Copy directory tree with byte progress (tar pipe; preserves mode/mtime/symlinks).
# Falls back to cp -a if python3 is missing or the progress pipe fails.
lumi_progress_cp_tree() {
	local src="$1"
	local dest="$2"
	local label="${3:-copy}"
	local bytes st

	[[ -d "${src}" ]] || {
		echo "lumi_progress_cp_tree: not a directory: ${src}" >&2
		return 1
	}
	mkdir -p "${dest}"

	if ! _lumi_progress_have_python; then
		cp -a -- "${src}/." "${dest}/"
		return 0
	fi

	bytes="$(du -sb "${src}" 2>/dev/null | awk '{print $1}')"
	bytes="${bytes:-0}"
	set +e
	tar -C "${src}" --numeric-owner -cf - . \
		| _lumi_progress_bytes_filter "${bytes}" "${label}" \
		| tar -C "${dest}" --numeric-owner -xf -
	st=$?
	set -e
	_lumi_progress_clear_line
	if [[ "${st}" -ne 0 ]]; then
		echo "lumi_progress_cp_tree: progress pipe failed (status=${st}); falling back to cp -a" >&2
		find "${dest}" -mindepth 1 -maxdepth 1 -exec rm -rf {} +
		cp -a -- "${src}/." "${dest}/"
	fi
	return 0
}

# Create reproducible xz payload like: tar --sort=name --owner=0 --group=0 --numeric-owner -C CWD -cJf OUT .
# Writes to a temp file then renames, so root-owned OUT in a writable dir can still be replaced.
# Usage: lumi_pack_tar_xz OUTFILE LABEL CWD [MEMBER...]
lumi_pack_tar_xz() {
	local out="$1"
	local label="$2"
	local cwd="$3"
	shift 3
	local members=("$@")
	local bytes out_dir tmp st ps m

	[[ -d "${cwd}" ]] || {
		echo "lumi_pack_tar_xz: not a directory: ${cwd}" >&2
		return 1
	}
	[[ ${#members[@]} -gt 0 ]] || members=(.)
	out_dir="$(dirname -- "${out}")"
	mkdir -p "${out_dir}"

	if [[ ${#members[@]} -eq 1 && "${members[0]}" == "." ]]; then
		bytes="$(du -sb "${cwd}" 2>/dev/null | awk '{print $1}')"
	else
		bytes=0
		for m in "${members[@]}"; do
			if [[ -e "${cwd}/${m}" ]]; then
				bytes=$((bytes + $(du -sb "${cwd}/${m}" 2>/dev/null | awk '{print $1}')))
			fi
		done
	fi
	bytes="${bytes:-0}"

	tmp="$(mktemp "${out_dir}/.lumi-pack-XXXXXX.tar.xz")"
	# shellcheck disable=SC2064
	trap 'rm -f -- "${tmp}"' RETURN

	set +e
	if _lumi_progress_have_python; then
		tar --sort=name --owner=0 --group=0 --numeric-owner -C "${cwd}" -cf - "${members[@]}" \
			| _lumi_progress_bytes_filter "${bytes}" "${label}" \
			| xz -c >"${tmp}"
		ps=("${PIPESTATUS[@]}")
		st=0
		for m in "${ps[@]}"; do
			[[ "${m}" -ne 0 ]] && st="${m}"
		done
	else
		tar --sort=name --owner=0 --group=0 --numeric-owner -C "${cwd}" \
			-cJf "${tmp}" "${members[@]}"
		st=$?
	fi
	set -e
	_lumi_progress_clear_line

	if [[ "${st}" -ne 0 ]]; then
		echo "lumi_pack_tar_xz: failed (status=${st})" >&2
		return "${st}"
	fi
	mv -f -- "${tmp}" "${out}"
	trap - RETURN
	return 0
}
