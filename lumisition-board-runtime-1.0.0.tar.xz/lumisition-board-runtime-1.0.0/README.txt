lumisition board runtime 1.0.0
Apps: lumi-locomotion
Docs: /opt/lumisition/doc/  (from lumisition-Service/doc/runtime)
Host: install.sh also caps /var/log/syslog and /var/log/kern.log (~50MB)

On the test board (no source required):
  tar -xJf lumisition-board-runtime-1.0.0.tar.xz
  cd lumisition-board-runtime-1.0.0
  sudo bash install.sh --now
