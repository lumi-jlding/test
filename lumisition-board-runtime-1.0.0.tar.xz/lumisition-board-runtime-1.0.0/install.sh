#!/usr/bin/env bash
# Install a packed lumisition board runtime onto a machine that has NO business
# source trees. Catalog is doc/runtime (eleven apps). Also installs those pages
# to /opt/lumisition/doc/.
#
#   /opt/lumisition/<app>/releases/<version>   (this bundle's VERSION, default 1.0.0)
#   /opt/lumisition/<app>/current -> releases/<version>
#
# systemd units and /usr/local/bin links only reference /opt/lumisition/.../current
# or files copied into /usr/local (AIC init, selfcheck-ready). They never point at
# /home/lumisition/{hardware_SDK,lumi-locomotion,lumisition-Service}.
#
# Public environment that must already exist on the test board (not in this pack):
#   /usr/local/lib                          CycloneDDS / gRPC
#   /home/lumisition/librknn_api/aarch64    loco RKNN runtime
#   python3 / GStreamer / NetworkManager / bluetooth as required by each app
#
# Usage (from the extracted bundle directory):
#   sudo bash install.sh
#   sudo bash install.sh --now
#   sudo bash install.sh --no-start
#   sudo bash install.sh --apps hal-fanout,lumi-locomotion --now
set -euo pipefail

SCRIPT_PATH="$(readlink -f -- "${BASH_SOURCE[0]}")"
BUNDLE_ROOT="$(cd -- "$(dirname -- "${SCRIPT_PATH}")" && pwd)"
VERSION="$(tr -d '[:space:]' <"${BUNDLE_ROOT}/VERSION" 2>/dev/null || true)"
OPT_ROOT="/opt/lumisition"
START_NOW=0
DO_ENABLE=1
APPS_FILTER=""
FORCE=0

# Prefer bundled host/ copy (source-less boards); fall back to package-OTA tree.
if [[ -f "${BUNDLE_ROOT}/host/pack-progress.sh" ]]; then
	# shellcheck source=/dev/null
	source "${BUNDLE_ROOT}/host/pack-progress.sh"
elif [[ -f "${BUNDLE_ROOT}/../tools/lib/pack-progress.sh" ]]; then
	# shellcheck source=/dev/null
	source "${BUNDLE_ROOT}/../tools/lib/pack-progress.sh"
fi

usage() {
	cat <<'EOF'
Usage: sudo bash install.sh [--now|--no-start] [--apps a,b,...] [--force]

  (default)   Copy releases to /opt/lumisition, install units and links, enable
              boot units, do not start them.
  --now       Same, then start services in dependency order.
  --no-start  Same as default (explicit).
  --apps      Comma-separated subset of apps present in this bundle.
  --force     Replace existing releases/<version> even if current points elsewhere.

This script never compiles and never reads business source under /home/lumisition.
EOF
}

while [[ $# -gt 0 ]]; do
	case "$1" in
	--now) START_NOW=1; shift ;;
	--no-start) START_NOW=0; shift ;;
	--force) FORCE=1; shift ;;
	--apps)
		[[ $# -ge 2 ]] || { usage >&2; exit 64; }
		APPS_FILTER="$2"
		shift 2
		;;
	-h|--help) usage; exit 0 ;;
	*) usage >&2; exit 64 ;;
	esac
done

die() {
	echo "install-board-runtime: $*" >&2
	exit 1
}

warn() {
	echo "install-board-runtime: warning: $*" >&2
}

[[ "${EUID}" -eq 0 ]] || die "run through sudo"
[[ -n "${VERSION}" ]] || die "missing VERSION in ${BUNDLE_ROOT}"
[[ "${VERSION}" =~ ^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$ ]] || \
	die "VERSION must be SemVer X.Y.Z: ${VERSION}"
[[ -d "${BUNDLE_ROOT}/apps" ]] || die "bundle is missing apps/: ${BUNDLE_ROOT}/apps"
[[ -d "${BUNDLE_ROOT}/systemd" ]] || die "bundle is missing systemd/"

if [[ "$(uname -m)" != "aarch64" ]]; then
	warn "this installer is meant for RK3588 aarch64; uname -m is $(uname -m)"
fi

mapfile -t AVAILABLE_APPS < <(find "${BUNDLE_ROOT}/apps" -mindepth 1 -maxdepth 1 -type d -printf '%f\n' | sort)
[[ ${#AVAILABLE_APPS[@]} -gt 0 ]] || die "bundle apps/ is empty"

SELECTED_APPS=()
if [[ -z "${APPS_FILTER}" ]]; then
	SELECTED_APPS=("${AVAILABLE_APPS[@]}")
else
	IFS=',' read -r -a requested <<< "${APPS_FILTER}"
	for name in "${requested[@]}"; do
		name="${name// /}"
		[[ -n "${name}" ]] || continue
		[[ -d "${BUNDLE_ROOT}/apps/${name}" ]] || die "app not in this bundle: ${name}"
		SELECTED_APPS+=("${name}")
	done
	[[ ${#SELECTED_APPS[@]} -gt 0 ]] || die "--apps selected nothing"
fi

app_selected() {
	local needle="$1" item
	for item in "${SELECTED_APPS[@]}"; do
		[[ "${item}" == "${needle}" ]] && return 0
	done
	return 1
}

if ! getent group lumisition >/dev/null 2>&1; then
	groupadd lumisition
	echo "created group lumisition (needed by os-env-selfcheck.service)"
fi

if [[ ! -d /home/lumisition/librknn_api/aarch64 ]] && app_selected lumi-locomotion; then
	warn "missing /home/lumisition/librknn_api/aarch64; lumi-locomotion will not run until RKNN is present"
fi

install -d -o root -g root -m 0755 "${OPT_ROOT}"
[[ "$(stat -c '%U:%G' "${OPT_ROOT}")" == "root:root" ]] || \
	die "application root must be root:root: ${OPT_ROOT}"

link_command() {
	local source_path="$1"
	local command_name="$2"
	local target_path="/usr/local/bin/${command_name}"

	[[ -e "${source_path}" ]] || {
		warn "skip link ${command_name}: missing ${source_path}"
		return 0
	}
	if [[ -e "${target_path}" && ! -L "${target_path}" ]]; then
		die "refusing to replace non-symlink: ${target_path}"
	fi
	ln -sfn "${source_path}" "${target_path}"
	echo "  link ${target_path} -> ${source_path}"
}

install_app_release() {
	local app="$1"
	local src="${BUNDLE_ROOT}/apps/${app}"
	local dest="${OPT_ROOT}/${app}/releases/${VERSION}"
	local stage="${dest}.installing.$$"

	[[ -f "${src}/VERSION" ]] || die "app ${app} is missing VERSION"
	[[ "$(tr -d '[:space:]' <"${src}/VERSION")" == "${VERSION}" ]] || \
		die "app ${app} VERSION does not match bundle ${VERSION}"

	if [[ -e "${dest}" && "${FORCE}" -ne 1 ]]; then
		echo "replacing existing ${dest}"
	fi

	rm -rf -- "${stage}"
	install -d -o root -g root -m 0755 "${OPT_ROOT}/${app}/releases" "${stage}"
	if declare -F lumi_progress_cp_tree >/dev/null 2>&1; then
		lumi_progress_cp_tree "${src}" "${stage}" "install ${app}"
	else
		cp -a -- "${src}/." "${stage}/"
	fi
	chown -R root:root "${stage}"
	# Release trees must not contain escaping symlinks.
	if find "${stage}" -type l -lname '/*' | grep -q .; then
		rm -rf -- "${stage}"
		die "app ${app} contains absolute symlinks; refusing to install"
	fi
	rm -rf -- "${dest}"
	mv -T "${stage}" "${dest}"
	ln -sfn "releases/${VERSION}" "${OPT_ROOT}/${app}/current"
	ln -sfn "releases/${VERSION}" "${OPT_ROOT}/${app}/previous"
	echo "installed ${app} -> ${dest}"
}

should_preserve() {
	local rel="$1"
	case "${rel}" in
	etc/lumi/device-agent/device-agent.env) return 0 ;;
	etc/lumi/power-board-ota.conf) return 0 ;;
	etc/lumi/hal-selfcheck.conf) return 0 ;;
	etc/lumi/internet.conf) return 0 ;;
	etc/lumi/device-cloud.conf) return 0 ;;
	etc/lumi/service-switch.yaml) return 0 ;;
	etc/lumi/person-follow.conf) return 0 ;;
	etc/lumi/device-id) return 0 ;;
	etc/NetworkManager/system-connections/*) return 0 ;;
	*) return 1 ;;
	esac
}

overlay_mode_for() {
	local rel="$1"
	case "${rel}" in
	etc/NetworkManager/system-connections/*) echo 0600 ;;
	etc/lumi/device-agent/device-agent.env) echo 0640 ;;
	etc/lumi/power-board-ota.conf) echo 0600 ;;
	usr/local/bin/*|usr/local/lib/*|usr/local/sbin/*) echo 0755 ;;
	*) echo 0644 ;;
	esac
}

install_overlay() {
	local overlay="${BUNDLE_ROOT}/overlay"
	local rel dest mode
	[[ -d "${overlay}" ]] || return 0
	while IFS= read -r -d '' src; do
		rel="${src#"${overlay}/"}"
		dest="/${rel}"
		mode="$(overlay_mode_for "${rel}")"
		if [[ -e "${dest}" ]] && should_preserve "${rel}"; then
			echo "  keep existing ${dest}"
			continue
		fi
		install -D -o root -g root -m "${mode}" "${src}" "${dest}"
		echo "  overlay ${dest}"
	done < <(find "${overlay}" -type f -print0)
}

# BlueZ 5.64 only reads /etc/bluetooth/main.conf; main.conf.d drop-ins are ignored.
# Merge keys from the staged lumi-ble.conf into the OS main.conf so TemporaryTimeout
# and ReverseServiceDiscovery actually apply on factory images.
apply_bluez_main_conf() {
	local dropin="/etc/bluetooth/main.conf.d/lumi-ble.conf"
	local main="/etc/bluetooth/main.conf"
	[[ -f "${dropin}" ]] || return 0
	[[ -f "${main}" ]] || {
		warn "BlueZ main.conf missing; skip TemporaryTimeout apply"
		return 0
	}
	cp -a -- "${main}" "${main}.bak.lumi"
	python3 - "${main}" "${dropin}" <<'PY'
import re, sys
from pathlib import Path
main_path, dropin_path = Path(sys.argv[1]), Path(sys.argv[2])
text = main_path.read_text(encoding="utf-8")
keys = {}
for line in dropin_path.read_text(encoding="utf-8").splitlines():
	line = line.strip()
	if not line or line.startswith("#") or line.startswith("["):
		continue
	if "=" in line:
		k, v = line.split("=", 1)
		keys[k.strip()] = v.strip()
for key, value in keys.items():
	pattern = re.compile(rf"(?m)^#?\s*{re.escape(key)}\s*=.*$")
	replacement = f"{key} = {value}"
	if pattern.search(text):
		text = pattern.sub(replacement, text, count=1)
	elif re.search(r"(?m)^\[General\]\s*$", text):
		text = re.sub(r"(?m)^(\[General\]\s*)$", rf"\1\n{replacement}", text, count=1)
	else:
		text = f"[General]\n{replacement}\n" + text
main_path.write_text(text, encoding="utf-8")
PY
	echo "  applied BlueZ overrides into ${main}"
}

install_units() {
	local unit dest
	for unit in "${BUNDLE_ROOT}/systemd/"*.service; do
		[[ -f "${unit}" ]] || continue
		dest="/etc/systemd/system/$(basename -- "${unit}")"
		install -D -o root -g root -m 0644 "${unit}" "${dest}"
		echo "  unit ${dest}"
	done
	if [[ -d "${BUNDLE_ROOT}/systemd/dropins" ]]; then
		while IFS= read -r -d '' src; do
			rel="${src#"${BUNDLE_ROOT}/systemd/dropins/"}"
			dest="/etc/systemd/system/${rel}"
			install -D -o root -g root -m 0644 "${src}" "${dest}"
			echo "  drop-in ${dest}"
		done < <(find "${BUNDLE_ROOT}/systemd/dropins" -type f -print0)
	fi
}

install_runtime_links() {
	local current
	if app_selected hal-fanout; then
		link_command "${OPT_ROOT}/hal-fanout/current/bin/start_d1_hal_fanout.sh" start_hal_fanout.sh
	fi
	if app_selected lumi-locomotion; then
		link_command "${OPT_ROOT}/lumi-locomotion/current/bin/start_lumi_locomotion.sh" start_lumi_locomotion.sh
	fi
	if app_selected ble-wifi-provision; then
		current="${OPT_ROOT}/ble-wifi-provision/current/bin"
		link_command "${current}/ble-wifi-ensure-controller.sh" ble-wifi-ensure-controller.sh
		link_command "${current}/ble-wifi-run.sh" ble-wifi-run.sh
		link_command "${current}/ble-wifi-network.sh" ble-wifi-network.sh
		link_command "${current}/ble-wifi-gatt.py" ble-wifi-gatt.py
		link_command "${current}/lumi-device-id.sh" lumi-device-id.sh
		link_command "${current}/lumi-device-id-migrate-from-uuid.sh" lumi-device-id-migrate-from-uuid.sh
	fi
	if app_selected checklist; then
		link_command "${OPT_ROOT}/checklist/current/bin/hal-selfcheck" hal-selfcheck
		install -d -m 0755 /usr/local/lib/os-env-selfcheck
		ln -sfn "${OPT_ROOT}/checklist/current/libexec/os-env-selfcheck.sh" \
			/usr/local/lib/os-env-selfcheck/os-env-selfcheck.sh
	fi
	if app_selected lumi-device-agent; then
		link_command "${OPT_ROOT}/lumi-device-agent/current/bin/lumi-device-agent-run.sh" \
			lumi-device-agent-run.sh
		link_command "${OPT_ROOT}/lumi-device-agent/current/libexec/lumi-device-agent-preflight.sh" \
			lumi-device-agent-preflight.sh
		link_command "${OPT_ROOT}/lumi-device-agent/current/libexec/lumi-device-id.sh" \
			lumi-device-id.sh
		link_command "${OPT_ROOT}/lumi-device-agent/current/libexec/lumi-device-id-migrate-from-uuid.sh" \
			lumi-device-id-migrate-from-uuid.sh
	fi
	if app_selected power-board-ota; then
		link_command "${OPT_ROOT}/power-board-ota/current/bin/power-board-ota" power-board-ota
		link_command "${OPT_ROOT}/power-board-ota/current/bin/power-board-ota-run.sh" \
			power-board-ota-run.sh
	fi
	if app_selected internet-service; then
		current="${OPT_ROOT}/internet-service/current/bin"
		link_command "${current}/lumi-internet-run.sh" lumi-internet-run.sh
		link_command "${current}/lumi-internet-status.sh" lumi-internet-status.sh
		link_command "${current}/lumi-4g-detect.sh" lumi-4g-detect.sh
		link_command "${current}/lumi-4g-at.sh" lumi-4g-at.sh
	fi
	if app_selected lumi-device-cloud; then
		link_command "${OPT_ROOT}/lumi-device-cloud/current/bin/lumi-device-cloud.py" \
			lumi-device-cloud.py
	fi
	if app_selected service-manager; then
		link_command "${OPT_ROOT}/service-manager/current/bin/lumi-svc" lumi-svc
	fi
}

prepare_state_dirs() {
	install -d -o root -g root -m 0755 /etc/lumi /var/lib/lumisition
	if app_selected checklist; then
		install -d -o root -g lumisition -m 0750 /var/lib/os-env-selfcheck
		install -d -o root -g root -m 0755 /var/lib/hal-selfcheck
	fi
	if app_selected avm-webrtc; then
		install -d -o root -g root -m 0755 /var/lib/lumisition/avm-webrtc/snapshots
	fi
	if app_selected internet-service; then
		install -d -o root -g root -m 0755 /var/lib/lumi-internet
	fi
	if app_selected lumi-device-cloud; then
		install -d -o root -g root -m 0755 /run/lumi-device-cloud /var/lib/lumi-device-cloud
	fi
}

install_device_id() {
	local helper=""
	if app_selected ble-wifi-provision; then
		helper="${OPT_ROOT}/ble-wifi-provision/current/bin/lumi-device-id.sh"
	elif app_selected lumi-device-agent; then
		helper="${OPT_ROOT}/lumi-device-agent/current/libexec/lumi-device-id.sh"
	fi
	[[ -n "${helper}" && -f "${helper}" ]] || return 0
	export LUMI_DEVICE_ID_FILE="${LUMI_DEVICE_ID_FILE:-/etc/lumi/device-id}"
	# shellcheck disable=SC1090
	source "${helper}"
	lumi_device_id_install_file || \
		warn "could not write ${LUMI_DEVICE_ID_FILE} from eth0; BLE/Agent init may retry at boot"
}

try_unit() {
	local action="$1"
	local unit="$2"
	if ! systemctl cat "${unit}" >/dev/null 2>&1; then
		warn "skip ${action} ${unit}: unit not installed"
		return 0
	fi
	if systemctl "${action}" "${unit}"; then
		echo "  ${action} ${unit}"
		return 0
	fi
	warn "${action} ${unit} failed"
	systemctl --no-pager -l status "${unit}" >/dev/null 2>&1 || true
	return 1
}

start_services() {
	local failed=0
	systemctl unmask bluetooth.service >/dev/null 2>&1 || true

	if [[ -f /etc/systemd/system/lumi-aic8800-init.service ]]; then
		try_unit enable lumi-aic8800-init.service || true
		if [[ "${START_NOW}" -eq 1 ]]; then
			try_unit start lumi-aic8800-init.service || warn "AIC8800 init failed; BLE may retry"
		fi
	fi

	if app_selected ble-wifi-provision; then
		systemctl disable --now wifibt.service >/dev/null 2>&1 || true
		systemctl disable --now check-gRPC-server.service >/dev/null 2>&1 || true
		rm -f /etc/systemd/system/check-gRPC-server.service \
			/etc/systemd/system/lumi-sdk-grpc-dev.service \
			/etc/systemd/system/lumi-ble-provision.service
		try_unit enable ble-wifi-provision.service || failed=1
		if [[ "${START_NOW}" -eq 1 ]]; then
			try_unit start bluetooth.service || true
			try_unit start ble-wifi-provision.service || failed=1
		fi
	fi

	if app_selected checklist; then
		try_unit enable hal-selfcheck.service || failed=1
		try_unit enable os-env-selfcheck.service || failed=1
		if [[ "${START_NOW}" -eq 1 ]]; then
			try_unit restart selfcheck-ready.service || true
			try_unit restart hal-selfcheck.service || true
			try_unit restart os-env-selfcheck.service || true
		fi
	fi

	if app_selected lumi-device-agent; then
		systemctl disable --now check-gRPC-server.service >/dev/null 2>&1 || true
		try_unit enable lumi-device-agent.service || failed=1
		if [[ "${START_NOW}" -eq 1 ]]; then
			try_unit start lumi-device-agent.service || failed=1
		fi
	fi

	if app_selected hal-fanout; then
		systemctl disable --now d1-dds-bridge-imu.service >/dev/null 2>&1 || true
		try_unit enable d1-hal-fanout.service || failed=1
		if [[ "${START_NOW}" -eq 1 ]]; then
			try_unit restart d1-hal-fanout.service || failed=1
		fi
	fi

	if app_selected lumi-locomotion; then
		try_unit enable lumi-locomotion.service || failed=1
		if [[ "${START_NOW}" -eq 1 ]]; then
			try_unit restart lumi-locomotion.service || failed=1
		fi
	fi

	if app_selected avm-webrtc; then
		try_unit enable avm-webrtc.service || failed=1
		if [[ "${START_NOW}" -eq 1 ]]; then
			try_unit restart avm-webrtc.service || failed=1
		fi
	fi

	# person-follow-bridge.service has no [Install]; person-follow pulls it in (Wants=).
	if app_selected person-follow; then
		try_unit enable person-follow.service || failed=1
		if [[ "${START_NOW}" -eq 1 ]]; then
			try_unit restart person-follow.service || failed=1
		fi
	fi

	if app_selected internet-service; then
		if command -v udevadm >/dev/null 2>&1; then
			udevadm control --reload-rules >/dev/null 2>&1 || true
		fi
		if command -v nmcli >/dev/null 2>&1; then
			nmcli connection reload >/dev/null 2>&1 || true
		fi
		try_unit enable lumi-internet.service || failed=1
		if [[ "${START_NOW}" -eq 1 ]]; then
			try_unit restart lumi-internet.service || failed=1
		fi
	fi

	if app_selected lumi-device-cloud; then
		try_unit enable lumi-device-cloud.service || failed=1
		if [[ "${START_NOW}" -eq 1 ]]; then
			try_unit restart lumi-device-cloud.service || failed=1
		fi
	fi

	# Static: never enable power-board-ota.service
	return "${failed}"
}

install_syslog_size_limit() {
	local script="${BUNDLE_ROOT}/host/install-syslog-size-limit.sh"
	[[ -f "${script}" ]] || die "bundle is missing host/install-syslog-size-limit.sh"
	[[ -f "${BUNDLE_ROOT}/host/rotate-rsyslog-file.sh" ]] || \
		die "bundle is missing host/rotate-rsyslog-file.sh"
	echo "installing syslog size limit"
	bash "${script}"
}

install_runtime_docs() {
	local src="${BUNDLE_ROOT}/doc"
	local dest="${OPT_ROOT}/doc"
	local stage="${dest}.installing.$$"
	local name

	[[ -d "${src}" ]] || die "bundle is missing doc/ (runtime markdown)"
	rm -rf -- "${stage}"
	install -d -o root -g root -m 0755 "${stage}"
	cp -a -- "${src}/." "${stage}/"
	chown -R root:root "${stage}"
	find "${stage}" -type f -exec chmod 0644 {} +
	rm -rf -- "${dest}"
	mv -T "${stage}" "${dest}"
	echo "installed runtime docs -> ${dest}"
	for name in index.md hal-fanout.md lumi-locomotion.md ble-wifi-provision.md \
		checklist.md lumi-device-agent.md power-board-ota.md avm-webrtc.md \
		internet-service.md lumi-device-cloud.md service-manager.md person-follow.md; do
		[[ -f "${dest}/${name}" ]] || die "runtime doc missing after install: ${dest}/${name}"
	done
}

echo "Installing lumisition board runtime ${VERSION}"
echo "Bundle: ${BUNDLE_ROOT}"
echo "Apps:   ${SELECTED_APPS[*]}"

_INSTALL_STEPS=$((${#SELECTED_APPS[@]} + 4)) # docs + overlay + syslog + units
if [[ -d /run/systemd/system && "${DO_ENABLE}" -eq 1 ]]; then
	_INSTALL_STEPS=$((_INSTALL_STEPS + 1))
fi
if declare -F lumi_progress_begin >/dev/null 2>&1; then
	lumi_progress_begin "${_INSTALL_STEPS}" "install runtime ${VERSION}"
fi

for app in "${SELECTED_APPS[@]}"; do
	if declare -F lumi_progress_step >/dev/null 2>&1; then
		lumi_progress_step "install ${app}"
	fi
	install_app_release "${app}"
done

if declare -F lumi_progress_step >/dev/null 2>&1; then
	lumi_progress_step "runtime docs"
fi
install_runtime_docs
prepare_state_dirs
if declare -F lumi_progress_step >/dev/null 2>&1; then
	lumi_progress_step "overlay + bluez"
fi
install_overlay
apply_bluez_main_conf
if declare -F lumi_progress_step >/dev/null 2>&1; then
	lumi_progress_step "syslog size limit"
fi
install_syslog_size_limit
if declare -F lumi_progress_step >/dev/null 2>&1; then
	lumi_progress_step "units + links"
fi
install_units
install_runtime_links
install_device_id

if [[ -d /run/systemd/system ]]; then
	systemctl daemon-reload
	if [[ "${DO_ENABLE}" -eq 1 ]]; then
		if declare -F lumi_progress_step >/dev/null 2>&1; then
			lumi_progress_step "enable/start units"
		fi
		if start_services; then
			:
		else
			warn "one or more units failed to enable/start; files are installed"
			echo "Inspect with: systemctl status d1-hal-fanout lumi-locomotion lumi-device-agent ble-wifi-provision"
			exit 1
		fi
	fi
else
	warn "systemd is not running; files installed. Enable units on first boot."
fi

if declare -F lumi_progress_end >/dev/null 2>&1; then
	lumi_progress_end
fi

echo
echo "Done. Runtime root: ${OPT_ROOT}/<app>/current -> releases/${VERSION}"
echo "Runtime docs: ${OPT_ROOT}/doc/  (index.md)"
echo "power-board-ota.service is static and was not enabled."
if [[ "${START_NOW}" -eq 0 ]]; then
	echo "Units are enabled (where applicable). Start with: sudo bash ${SCRIPT_PATH} --now"
fi
