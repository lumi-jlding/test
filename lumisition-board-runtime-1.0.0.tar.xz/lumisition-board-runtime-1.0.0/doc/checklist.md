# checklist

清单：[index.md](index.md)

## 身份

一个 `/opt` 应用，两个业务 oneshot，外加一个**不要 enable** 的就绪门。

| 项 | 值 |
| --- | --- |
| `/opt` 目录 | `/opt/lumisition/checklist/current` |
| HAL 自检 | `hal-selfcheck.service` → `current/bin/hal-selfcheck --config /etc/lumi/hal-selfcheck.conf` |
| OS 自检 | `os-env-selfcheck.service` → `current/libexec/os-env-selfcheck.sh` |
| 就绪门 | `selfcheck-ready.service`（静态；脚本在 `/usr/local/lib/selfcheck-ready/`，**不在本包**） |
| 类型 | 均为 oneshot，`RemainAfterExit=yes` |
| OTA 钩子 | 有；`start` 会 `restart` 两项自检，**不碰** `selfcheck-ready` |

`SuccessExitStatus`：HAL 允许退出码 `1`；OS 允许 `1` `2`。unit 显示 `active` 只表示脚本跑完，**不等于硬件全部合格**。看 JSON。

## 做什么 / 不做什么

做：开机对 HAL 设备与 OS 环境做只读检查，写报告。HAL 默认不要求电机反馈（`require_motor_feedback=false`），不使能电机。

不做：OTA、配网、fanout。Agent 只在 RPC 时**读**这些 JSON，不等待自检结束才监听 `:50052`。

## 日常操作

```bash
sudo systemctl enable hal-selfcheck.service os-env-selfcheck.service
# 不要：systemctl enable selfcheck-ready.service
sudo systemctl start hal-selfcheck.service     # 会 Requires 拉起就绪门
sudo systemctl start os-env-selfcheck.service
sudo systemctl restart hal-selfcheck.service os-env-selfcheck.service
systemctl is-active selfcheck-ready.service hal-selfcheck.service os-env-selfcheck.service
```

oneshot 已 `active (exited)` 时，要再跑一轮用 `restart`，不要只 `start`。

## 配置与状态

HAL：`/etc/lumi/hal-selfcheck.conf`

- 报告：`/var/lib/hal-selfcheck/report.json`
- 电源板串口配置项默认 `/dev/ttyS9`（自检配置，不是 MCU OTA 的 `/dev/ttyS7`）
- `use_stub=false` 为产品默认

OS：

- 输出：`/var/lib/os-env-selfcheck/`（含 `result.json`）
- `StateDirectoryMode=0750`，组 `lumisition`

就绪门：等 local-fs、udev、NetworkManager、`sensor-init.service`；完成后非阻塞再 start 两项自检。

## 依赖与互斥

- 两项自检 `Requires=selfcheck-ready.service`
- Device Agent `Wants` 这两项，但 **After 不含自检**，避免堵住 `:50052`
- 不要停 `selfcheck-ready` 来「修」自检；修 JSON 与 `hal-selfcheck.conf`

## 日志与检查

```bash
journalctl -u selfcheck-ready.service -u hal-selfcheck.service -u os-env-selfcheck.service -b -n 80 --no-pager
cat /var/lib/hal-selfcheck/report.json
cat /var/lib/os-env-selfcheck/result.json
```

## 不要做

- 不要 enable 或手工长期操作 `selfcheck-ready.service`。
- 不要把 unit `active` 当成自检通过。
- 不要从 checklist 源码树跑 `hal-selfcheck`。
