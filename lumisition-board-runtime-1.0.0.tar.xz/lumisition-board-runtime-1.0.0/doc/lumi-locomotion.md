# lumi-locomotion

清单：[index.md](index.md)

## 身份

| 项 | 值 |
| --- | --- |
| `/opt` 目录 | `/opt/lumisition/lumi-locomotion/current` |
| unit | `lumi-locomotion.service` |
| 类型 | 常驻 `simple`；可 enable；`WantedBy=multi-user.target` |
| ExecStart（目标态） | `/opt/lumisition/lumi-locomotion/current/bin/start_lumi_locomotion.sh` |
| 进程 | `loco` |
| OTA 钩子 | 有 `bin/{start,stop,healthcheck}` |
| 依赖 | 运行时需要 `d1_hal_fanout_bridge` 进程和 `/dev/shm/lumi_teleop_v1`。systemd 不因此启动 fanout |

本 unit 的开机开关挂在 `multi-user.target` 上，与 `d1-hal-fanout.service` 互不拉起。enable 之后，下次开机会自己启动；fanout 启停不会带动它。

## 做什么 / 不做什么

做：在 fanout 与遥控共享内存就绪后，用 RKNN 跑 `policy/`（`lumi_w`）。工作目录必须是 `current`，相对路径 `policy/` 才有效。

不做：HAL、`:50051`、电机使能（这些是 fanout）；不打开 `/dev/ttyS7`。

## 日常操作

```bash
sudo systemctl enable lumi-locomotion.service
sudo systemctl start lumi-locomotion.service    # 不会把 fanout 拉起来
sudo systemctl restart lumi-locomotion.service
sudo systemctl stop lumi-locomotion.service
systemctl is-enabled lumi-locomotion.service
systemctl is-active lumi-locomotion.service
```

`systemctl stop d1-hal-fanout.service` 不会停掉 loco。刷 MCU 时如需让运控退出，请另行 `sudo systemctl stop lumi-locomotion.service`。

OTA 钩子 `bin/start` 只 `systemctl restart` 本 unit，不启动 fanout。开发者日常不要调钩子。

## 配置与状态

- 二进制：`current/bin/loco`
- 策略：`current/policy/robots/lumi_w/modes.yaml`
- 环境：`LUMI_LOCO_ROOT` / `LUMI_LOCO_BIN` / `HAL_FANOUT_BIN`（unit 已设到 `/opt/.../current`）
- 默认网卡 `eth0`、后端 `rknn`；等 fanout + shm 最长 120 s

`LD_LIBRARY_PATH` 含 `/usr/local/lib` 和历史路径 `/home/lumisition/librknn_api/aarch64`。无源码树时优先依赖系统 `librknnrt`（常见为 `/usr/lib/librknnrt.so`）。若板子还缺 RKNN 运行库，loco 起不来，这与业务 git 无关。

## 板上 unit 可能落后

目标态 `ExecStart` 必须是 `/opt/.../current/bin/start_lumi_locomotion.sh`。

若 `systemctl cat lumi-locomotion.service` 仍是 `ExecStart=/usr/local/bin/start_lumi_locomotion.sh`，且该软链指向 `/home/...` 源码树，则当前板不能按「无 `/home`」运行。处理：把 unit 换成仓库 `hal-fanout/systemd/lumi-locomotion.service` 后 `daemon-reload`。`/usr/local/bin` 软链若指向 `/opt/.../current/bin/start_lumi_locomotion.sh` 可以保留，但 unit 仍应直接 ExecStart `/opt`。

## 依赖与互斥

- `After=d1-hal-fanout.service` 只排序，不构成启动或停止依赖
- 启动脚本需要 fanout 进程 `d1_hal_fanout_bridge` 与 `/dev/shm/lumi_teleop_v1`；没有就超时失败
- 与 MCU OTA 无直接串口冲突；停 fanout 刷板时本服务保持原状态

## 日志与检查

```bash
journalctl -u lumi-locomotion.service -b -n 80 --no-pager
systemctl is-active d1-hal-fanout.service lumi-locomotion.service
ls -l /dev/shm/lumi_teleop_v1
pgrep -a loco
cat /opt/lumisition/lumi-locomotion/current/VERSION
```

## 不要做

- 不要在 fanout inactive 时反复 start loco（包装脚本会等到超时失败）。
- 不要从 `/home/lumisition/lumi-locomotion` 跑 `loco`。
- 不要假定 enable fanout 会自动 enable 本 unit：本 unit 也要 enable。
