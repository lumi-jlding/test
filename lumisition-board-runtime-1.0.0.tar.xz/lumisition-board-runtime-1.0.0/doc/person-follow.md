# person-follow

清单：[index.md](index.md)

## 身份

| 项 | 值 |
| --- | --- |
| `/opt` 目录 | `/opt/lumisition/person-follow/current` |
| unit | `person-follow.service`（感知，enable）、`person-follow-bridge.service`（DDS 转发，static，被前者拉起） |
| 类型 | 常驻 `simple` |
| ExecStart | `/usr/bin/python3 -u .../current/bin/person_follow_run.py infer` / `bridge` |
| 配置 | `/etc/lumi/person-follow.conf`（覆盖 `current/config/person-follow.conf`） |
| 端口 | `127.0.0.1:8080`（avm-webrtc 锁定转发）；eth0 有 IPv4 后另绑 `eth0:8080` 调试页 |
| OTA 钩子 | 有 |

## 做什么 / 不做什么

做：读 avm-webrtc 前向帧（`/tmp/avm_front.sock`）跑 YOLO11n + BoT-SORT，App 点选锁定后算 `vx/yaw`，写 `/run/person-follow/cmd.json`；bridge 以 25 Hz 转成 `rt/lumi/vel_cmd`。

不做：交权。机器人只有在 Walk + 手柄 RB+Y / App 切导航（owner=Navigation）且已锁定目标时才会动。

## 日常操作

```bash
sudo systemctl enable --now person-follow.service
sudo systemctl restart person-follow.service     # bridge 跟着重启
sudo systemctl stop person-follow.service        # bridge 跟着停，停前各发一帧零速
systemctl is-active person-follow.service person-follow-bridge.service
```

改参数：编辑 `/etc/lumi/person-follow.conf` 后 restart。key 即命令行参数去掉 `--`；`true` 传开关、`false` 不传。

```bash
/usr/bin/python3 /opt/lumisition/person-follow/current/bin/person_follow_run.py check
```

## 日志与检查

```bash
journalctl -u person-follow -u person-follow-bridge -b -n 100 --no-pager
cat /run/person-follow/cmd.json
curl -s http://127.0.0.1:8080/stats
```

启动日志 `follow effective d*=…` 是实际跟随距离（单目测距下限会抬高过小的 `d-star`）。bridge 日志 `valid=0 state=stale` 表示感知没在更新。

## 依赖与互斥

- 需要 `avm-webrtc.service` 在跑（否则一直等前向 socket）；与 loco 只通过 DDS 交互
- 占用 TCP `8080`；不要再从 `hardware_SDK/.../board_deploy` 手工起 `infer_board.py` / bridge（抢端口、双路发 `vel_cmd`）
- 系统依赖：`/usr/bin/python3` 的 numpy / OpenCV、`rknnlite`、`cyclonedds`，`/usr/lib/librknnrt.so`
- `CPUAffinity=6 7`（与 avm 同在视觉核）
