# `/opt/lumisition` 服务使用清单

板上业务以 `/opt/lumisition/<app>/current` 为准。日常启停只用 `systemctl`。
本目录是这套文档的源；部署后对应 `/opt/lumisition/doc/`。

本文不讲实现、不讲源码树、不讲打包。假设 `/home` 与业务 git 在运行时不存在。

---

## 命名对照（先看这里）

| 口头 / 旧名 | `/opt` 目录 | systemd unit | 说明 |
| --- | --- | --- | --- |
| fanout / HAL | `hal-fanout` | `d1-hal-fanout.service` | App gRPC `:50051` |
| loco / 运控 | `lumi-locomotion` | `lumi-locomotion.service` | 与 fanout 分开启停 |
| ble-wifi / 配网 | `ble-wifi-provision` | `ble-wifi-provision.service` | 另需 `lumi-aic8800-init` |
| 自检 / checklist | `checklist` | `hal-selfcheck.service`、`os-env-selfcheck.service` | 就绪门 `selfcheck-ready` 不要单独 enable |
| ota / Agent | `lumi-device-agent` | `lumi-device-agent.service` | 局域网 `:50052` SelfCheck + OTA |
| 电源板 MCU OTA | `power-board-ota` | `power-board-ota.service` | 静态，禁止 enable |
| AVM / 环视 | `avm-webrtc` | `avm-webrtc.service` | 信令 `ws://0.0.0.0:8081/` |
| 跟随 / YOLO | `person-follow` | `person-follow.service`（+ `person-follow-bridge.service`） | 前向帧来自 avm；发 `rt/lumi/vel_cmd` |
| 公网出口 / 4G | `internet-service` | `lumi-internet.service` | 目录名 ≠ unit 名 |
| 云通道 / DeviceOps | `lumi-device-cloud` | `lumi-device-cloud.service` | **不是** `lumi-device-agent` |
| 总开关 / lumi-svc | `service-manager` | **无** | 命令 `/usr/local/bin/lumi-svc`，不是开机服务 |

已删除、不要再启：`check-gRPC-server.service`（旧独立 `:50052`）。

---

## 十一个应用

| 文档 | 类型 | 建议 enable | `bin/{start,stop,healthcheck}` | 一句话 |
| --- | --- | --- | --- | --- |
| [hal-fanout.md](hal-fanout.md) | 常驻 | 是 | 有（安装器生命周期，内部仍调 systemctl） | HAL + DDS + App `:50051` |
| [lumi-locomotion.md](lumi-locomotion.md) | 常驻 | 是（`WantedBy=multi-user.target`） | 有 | RKNN 运控；与 fanout 分开启停 |
| [ble-wifi-provision.md](ble-wifi-provision.md) | 常驻 | 是 | 有 | BLE 配网 + SoftAP |
| [checklist.md](checklist.md) | oneshot | 是（两项自检） | 有 | 开机自检，写 JSON |
| [lumi-device-agent.md](lumi-device-agent.md) | 常驻 | 是 | 有 | `:50052` 自检 RPC + 应用 OTA |
| [power-board-ota.md](power-board-ota.md) | oneshot **静态** | **否** | 有；`start` **不刷 MCU** | 手工刷电源板 |
| [avm-webrtc.md](avm-webrtc.md) | 常驻 | 是 | 有 | 环视 WebRTC |
| [person-follow.md](person-follow.md) | 常驻 | 是（只 enable 主 unit） | 有 | 人员跟随感知 + vel_cmd 转发 |
| [internet-service.md](internet-service.md) | 常驻 | 是 | **无** | Wi-Fi / 4G 出口策略 |
| [lumi-device-cloud.md](lumi-device-cloud.md) | 常驻 | 是 | **无** | 出站 DeviceOps |
| [service-manager.md](service-manager.md) | 命令 | 不适用（无 unit） | **无** | 白名单启停与 journal；内部仍调 systemctl |

`bin/start`、`bin/stop`、`bin/healthcheck` 是 **application OTA 安装器**用的钩子，不是给开发者当业务 start。没有这套钩子的应用（internet / cloud / service-manager）不能当 application OTA 包。业务服务仍用 `systemctl`；白名单批量开关用 `lumi-svc`。

---

## 依赖与互斥

```text
multi-user.target
  ├─ lumi-aic8800-init.service          （BLE 前置，包外脚本）
  ├─ ble-wifi-provision.service
  ├─ lumi-device-agent.service
  │     Requires  lumi-device-agent-init.service（静态）
  │     :50052
  ├─ hal-selfcheck.service ─┐
  ├─ os-env-selfcheck.service ─┴─ Requires selfcheck-ready.service（静态，不要 enable）
  ├─ d1-hal-fanout.service          :50051，独占 /dev/ttyS7
  ├─ lumi-locomotion.service        与 fanout 分开启停
  ├─ avm-webrtc.service             :8081，/dev/video0..3
  ├─ person-follow.service          127.0.0.1:8080；读 /tmp/avm_front.sock
  │     Wants/PartOf  person-follow-bridge.service → rt/lumi/vel_cmd
  ├─ lumi-internet.service
  └─ lumi-device-cloud.service      出站；不代替 Agent

手工：power-board-ota.service      刷前必须停 fanout
```

| 冲突 | 处理 |
| --- | --- |
| fanout ↔ `power-board-ota` | 都要用 `/dev/ttyS7`。刷 MCU 前 `systemctl stop d1-hal-fanout.service`，确认 `fuser /dev/ttyS7` 为空 |
| fanout / loco | 开关独立。起、停、重启一边不会带动另一边。loco 自己的启动脚本仍会等 bridge 和 `/dev/shm/lumi_teleop_v1`，等不到就失败，但不会去启动 fanout |
| `:50052` | 只允许 `lumi-device-agent` |
| Agent vs cloud | Agent = 局域网 OTA/自检；cloud = 出站心跳/日志/Web 终端 |

---

## 通用命令

```bash
# 版本与布局
readlink -f /opt/lumisition/<app>/current
cat /opt/lumisition/<app>/current/VERSION

# 业务启停（替换成上表 unit）
sudo systemctl enable --now <unit>
sudo systemctl restart <unit>
sudo systemctl stop <unit>
systemctl is-enabled <unit>
systemctl is-active <unit>
systemctl status <unit> --no-pager
journalctl -u <unit> -b -n 80 --no-pager

# 白名单总开关（见 service-manager.md）
lumi-svc status
sudo lumi-svc logs <id>
```

不要从 `/home` 跑二进制，不要手工 `exec` 安装器钩子来代替 `systemctl`。

---

## 不在本套文档里

- `package-OTA`、factory 一键包：打包机/首次预置，不是日常运维
- `hardware_SDK`、`ahd_calibration`：源码；运行时产物已在 `hal-fanout` / `avm-webrtc`
- `can-irq-affinity`、`lumi_bb_session`：可选主机 unit，不是这 10 个应用
- `lumi-device-agent-backups/`：备份目录，不是服务
