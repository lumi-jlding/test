# avm-webrtc

清单：[index.md](index.md)

## 身份

| 项 | 值 |
| --- | --- |
| `/opt` 目录 | `/opt/lumisition/avm-webrtc/current` |
| unit | `avm-webrtc.service` |
| 类型 | 常驻 `simple`；可 enable |
| ExecStart | `/opt/lumisition/avm-webrtc/current/bin/run_avm_webrtc_daemon.sh` |
| 信令 | `ws://0.0.0.0:8081/` |
| OTA 钩子 | 有 |
| 标定 | `current/share/calib/1920x1080/` |

不读 `hardware_SDK` / `ahd_calibration` 源码树。库在 `current/lib/`（`libbev_engine.so`、`libsvlib.so`、`libahd_camera.so*`），Python 在 `current/server/`。

## 做什么 / 不做什么

做：四路 AHD（`/dev/video0..3`）+ 可选 BEV，WebRTC 预览。默认模式 `cam_bev`（旧 APP hello 无 mode 时保持双轨）。快照目录 `/var/lib/lumisition/avm-webrtc/snapshots`。

不做：电机、配网、OTA。

## 日常操作

```bash
sudo systemctl enable --now avm-webrtc.service
sudo systemctl restart avm-webrtc.service
sudo systemctl stop avm-webrtc.service
systemctl is-active avm-webrtc.service
```

启动脚本会 `fuser -k 8081/tcp` 并尝试释放 `/dev/video0..3`，再等摄像头最多约 30 s + 8 s settle。unit `TimeoutStartSec=180`。

只要相机、不要 BEV 时，给 unit 加 `Environment=AVM_WEBRTC_MODE=cam_only` 后 reload + restart。

## 配置与状态

| 路径 | 用途 |
| --- | --- |
| `current/lib/` | 引擎与相机 so；daemon 把它放进 `LD_LIBRARY_PATH` 最前 |
| `current/share/calib/1920x1080/` | 内参 / 标定 |
| `current/server/avm_webrtc_server.py` | 信令与推流 |
| `/var/lib/lumisition/avm-webrtc/snapshots` | 快照 |
| `LUMI_AVM_SNAPSHOT_DIR` | 可覆盖快照目录 |

unit 清空代理环境变量，避免 WebRTC 走代理。

## 依赖与互斥

- `RequiresMountsFor=/opt/lumisition/avm-webrtc`
- 占用 `/dev/video0..3` 与 TCP `8081`；HAL 自检也会用 `/dev/video0` 抓一帧，开机窗口可能交叉，一般自检 oneshot 很快结束
- 与 fanout / loco 无串口绑定

## 日志与检查

```bash
journalctl -u avm-webrtc.service -b -n 80 --no-pager
ss -ltnp | grep ':8081'
ls /dev/video0 /dev/video1 /dev/video2 /dev/video3
cat /opt/lumisition/avm-webrtc/current/VERSION
```

日志里应出现 `signaling ws://0.0.0.0:8081/`，库路径在 `/opt/lumisition/avm-webrtc/`。

## 不要做

- 不要从 `ahd_calibration` 源码目录起 server。
- 不要在未停服务时再手工起一份 `avm_webrtc_server.py`（会抢 8081 和 video 设备）。
