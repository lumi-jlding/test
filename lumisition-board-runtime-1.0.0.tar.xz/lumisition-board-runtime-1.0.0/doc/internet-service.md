# internet-service

清单：[index.md](index.md)

## 身份

| 项 | 值 |
| --- | --- |
| `/opt` 目录 | `/opt/lumisition/internet-service/current` |
| unit | `lumi-internet.service`（目录名 ≠ unit 名） |
| 类型 | 常驻 `simple`；可 enable |
| ExecStart | `/usr/local/bin/lumi-internet-run.sh` → 应指向 `current/bin/lumi-internet-run.sh` |
| 配置 | `/etc/lumi/internet.conf` |
| 状态 | `/run/lumi-internet/status.json` |
| OTA 钩子 | **无** `bin/{start,stop,healthcheck}`。只能 `systemctl`，不能当 application OTA 包 |

源码在独立仓库 `internet_service`，不在 `lumisition-Service`。本页只讲板上使用。

## 做什么 / 不做什么

做：公网出口策略。可选 Quectel EM05-G（ECM / `wwan0`）配合 Wi-Fi STA。默认 `WAN_POLICY=wifi-first`（Wi-Fi 优先、4G 兜底）。只改 NetworkManager metric，不长期手写默认路由。

不做：不改 BLE 配网逻辑；不 down `wlan0`；不把 4G 分享给 SoftAP 客户端。没插 4G 模组时服务保持空闲，**不当故障**（unit 不 `Requires` modem 设备）。

## 日常操作

```bash
sudo systemctl enable --now lumi-internet.service
sudo systemctl restart lumi-internet.service
sudo systemctl stop lumi-internet.service
systemctl is-active lumi-internet.service
```

改完 `/etc/lumi/internet.conf` 必须 `restart`。

状态查看（脚本在 current/bin，也可能已链到 `/usr/local/bin`）：

```bash
/opt/lumisition/internet-service/current/bin/lumi-internet-status.sh
/opt/lumisition/internet-service/current/bin/lumi-4g-detect.sh
ip route show default
```

## 配置与状态

`/etc/lumi/internet.conf`（重装不覆盖已有文件）。常用项：

| 项 | 典型值 | 含义 |
| --- | --- | --- |
| `WAN_POLICY` | `wifi-first` | 也可 `cellular-first` |
| `WIFI_IFACE` | `wlan0` | STA |
| `WWAN_IFACE` | `wwan0` | 4G |
| `WIFI_STA_PROFILE` | `lumi-app-wifi-dev` | NM STA 连接名 |
| `HOTSPOT_PROFILE` | `rk-hotspot-test` | 与 BLE 热点名对齐，本服务不接管配网 |
| `APN` / `APN_AUTO` | `cmnet` / 见包内表 | 强制 APN 或按 IMSI |
| `PROBE_HOSTS` | 公共 DNS | 绑接口探测 |
| `METRIC_PRIMARY` / `METRIC_BACKUP` | `50` / `600` | NM metric |

APN 表还可放 `/etc/lumi/apn-table.txt`（安装不覆盖）。4G USB 默认 `2c7c:030e`。

无模组预期：`module=absent`，STA 能出网时 egress 为 `wifi`，默认路由仍 `wlan0`。

## 依赖与互斥

- `Wants` / `After`：`NetworkManager.service`
- `ConditionPathExists=.../lumi-internet-run.sh`：current 缺失则 unit 直接跳过
- 与 BLE 共用 `wlan0` / 热点名，但职责分离：BLE 配网，本服务管 WAN 优先级
- 不占用 `/dev/ttyS7`

## 日志与检查

```bash
journalctl -u lumi-internet.service -b -n 80 --no-pager
cat /run/lumi-internet/status.json
lsusb | grep -i 2c7c || true
readlink -f /usr/local/bin/lumi-internet-run.sh
```

`lumi-internet-run.sh` 解析结果应在 `/opt/lumisition/internet-service/` 下。

## 不要做

- 不要当 OTA 组件发包（缺安装器钩子）。
- 不要用本仓库 `install.sh` 当板上日常 start（那是开发机安装）。
- 不要 down `wlan0` 来「强制切 4G」。
