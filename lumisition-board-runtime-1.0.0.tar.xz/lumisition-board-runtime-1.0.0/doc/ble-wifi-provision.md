# ble-wifi-provision

清单：[index.md](index.md)

## 身份

| 项 | 值 |
| --- | --- |
| `/opt` 目录 | `/opt/lumisition/ble-wifi-provision/current` |
| 主 unit | `ble-wifi-provision.service` |
| 前置 unit | `lumi-aic8800-init.service`（oneshot；驱动不在本 application 包内） |
| 类型 | 常驻 `simple`；可 enable |
| ExecStart | `/opt/lumisition/ble-wifi-provision/current/bin/ble-wifi-run.sh` |
| ExecStartPre | `.../bin/ble-wifi-ensure-controller.sh` |
| OTA 钩子 | 有 `bin/{start,stop,healthcheck}` |

## 做什么 / 不做什么

做：BLE 广播与 GATT 配网、拉起 SoftAP（默认 NM 配置名 `rk-hotspot-test`）、把 `wlan0` 交给 NetworkManager。设备主键读 `/etc/lumi/device-id`。

不做：`:50052`（旧 `check-gRPC-server` 已删除，见 [lumi-device-agent.md](lumi-device-agent.md)）；不改 4G 策略（见 [internet-service.md](internet-service.md)）；不加载 AIC8800 以外的 Wi-Fi 栈。

## 日常操作

```bash
sudo systemctl enable --now lumi-aic8800-init.service
sudo systemctl enable --now ble-wifi-provision.service
sudo systemctl restart ble-wifi-provision.service
sudo systemctl stop ble-wifi-provision.service
systemctl is-active lumi-aic8800-init.service ble-wifi-provision.service
```

停 BLE **不会**停 Device Agent，也**不会**停 `:50051` fanout。

## 配置与状态

unit 环境（可 drop-in 覆盖）：

| 变量 | 默认 | 含义 |
| --- | --- | --- |
| `LUMI_HOTSPOT_PROFILE` | `rk-hotspot-test` | NM 热点连接名 |
| `LUMI_WIFI_IFACE` | `wlan0` | STA/AP 接口 |
| `LUMI_AP_IDLE_TIMEOUT` | `300` | 热点空闲超时（秒） |
| `LUMI_HCI_READY_TIMEOUT` | `180` | 等 `hci0` |
| `LUMI_DEVICE_ID_FILE` | `/etc/lumi/device-id` | 与 OTA / cloud 同一主键 |

AIC 初始化：`ConditionPathExists=/usr/local/modules/rk3588/aic8800_fdrv.ko`，脚本 `/usr/local/bin/lumi-aic8800-init.sh`（主机公共文件，不在 `/opt/.../ble-wifi-provision` payload）。

热点 / BlueZ / NM 连接配置在 `/etc`，不在 git 源码树。

## 依赖与互斥

- `Requires=lumi-aic8800-init.service`
- `Wants` / `After`：`NetworkManager.service`、`bluetooth.service`
- OTA 安装器可能给本 unit 加 drop-in，使其 `Requires` Device Agent 初始化；业务上 BLE 与 Agent 仍分开启停
- 不要再 enable `check-gRPC-server.service`

## 日志与检查

```bash
journalctl -u ble-wifi-provision.service -u lumi-aic8800-init.service -b -n 80 --no-pager
hciconfig -a
nmcli -t -f NAME,TYPE,DEVICE,STATE connection show
cat /etc/lumi/device-id
```

APP 配网完成后，自检/OTA 连 `RK_IP:50052`（Agent），实时控制连 `RK_IP:50051`（fanout）。

## 不要做

- 不要为了修 `:50052` 去重启或重装本服务。
- 不要设置已删除的 `LUMI_50052_OWNER=selfcheck`。
- 不要从 `/home/.../ble-wifi` 跑 `ble-wifi-run.sh`。
