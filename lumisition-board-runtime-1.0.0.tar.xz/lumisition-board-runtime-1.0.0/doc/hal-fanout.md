# hal-fanout

清单：[index.md](index.md)

## 身份

| 项 | 值 |
| --- | --- |
| `/opt` 目录 | `/opt/lumisition/hal-fanout/current` |
| unit | `d1-hal-fanout.service` |
| 类型 | 常驻 `simple`；可 enable；`WantedBy=multi-user.target` |
| ExecStart | `/opt/lumisition/hal-fanout/current/bin/start_d1_hal_fanout.sh` |
| 进程 | `d1_hal_fanout_bridge` |
| OTA 钩子 | 有 `bin/{start,stop,healthcheck}`（安装器生命周期，内部仍 `systemctl`） |
| 监听 | App gRPC `0.0.0.0:50051` |

不依赖 `hardware_SDK` 源码树。配置与二进制都在本 release 下。

## 做什么 / 不做什么

做：同一进程提供 HAL、运控 DDS、App `RobotService`（`:50051`）。默认变体 `HAL_VARIANT=leg_wheel`（16 电机）。默认**不**加 `--enable`，电机保持未使能。

不做：运控推理（见 [lumi-locomotion.md](lumi-locomotion.md)）；`:50052`（见 [lumi-device-agent.md](lumi-device-agent.md)）；电源板 MCU 刷写。

## 日常操作

```bash
sudo systemctl enable --now d1-hal-fanout.service
sudo systemctl restart d1-hal-fanout.service
sudo systemctl stop d1-hal-fanout.service
systemctl is-active d1-hal-fanout.service
systemctl status d1-hal-fanout.service --no-pager
```

停 fanout 不会停 `lumi-locomotion.service`。运控要单独 `sudo systemctl start lumi-locomotion.service` 或 `stop`。

需要开机就使能电机时，给 unit 加 `Environment=HAL_FANOUT_ENABLE=1` 后 `daemon-reload` 再 restart（工装/真机谨慎）。

## 配置与状态

Release 内（改完需 restart；OTA 升级会换整棵 current）：

- `config/d1_leg_wheel.yaml` / `d1_leg_only.yaml`
- `config/d1_dds_bridge_hal.yaml`
- `config/d1_grpc_bridge.yaml`（`listen_addr: 0.0.0.0:50051`）

运行时：

- 工作目录：`/opt/lumisition/hal-fanout/current`
- 遥控共享内存：`/dev/shm/lumi_teleop_v1`（loco 启动门槛）
- 可选黑盒：`EnvironmentFile=-/run/lumi/bb_session.env`（没有也不挡启动）

启动脚本会等 `/dev/bno08x`、`can0`、DDS 网卡（默认从 yaml 读，失败则 `eth0`），最长约 120 s。

## 依赖与互斥

- 需要：`/opt/lumisition/hal-fanout` 已挂载；建议 `network-online`。
- 互斥旧桥：`Conflicts=d1-dds-bridge-imu.service`；启动前会停旧 bridge / 旧 gRPC server。
- **独占 `/dev/ttyS7`**。刷电源板前必须停本服务，见 [power-board-ota.md](power-board-ota.md)。
- loco：开关独立，本服务的启停不带动 `lumi-locomotion.service`。

## 日志与检查

```bash
journalctl -u d1-hal-fanout.service -b -n 80 --no-pager
ss -ltnp | grep ':50051'
pgrep -a d1_hal_fanout_bridge
readlink -f /opt/lumisition/hal-fanout/current
cat /opt/lumisition/hal-fanout/current/VERSION
```

cmdline / cwd 应落在 `/opt/lumisition/hal-fanout/`，不应出现 `hardware_SDK`。

## 不要做

- 不要从 `/home` 或 SDK 源码目录启动 bridge。
- 不要手工跑 `bin/start` 当业务 start（那是 OTA 安装器钩子）。
- 不要与 `power-board-ota` 或 `power_board_cli` 同时打开 `/dev/ttyS7`。
