# lumi-device-cloud

清单：[index.md](index.md)

## 身份

| 项 | 值 |
| --- | --- |
| `/opt` 目录 | `/opt/lumisition/lumi-device-cloud/current` |
| unit | `lumi-device-cloud.service` |
| 类型 | 常驻 `simple`；可 enable |
| ExecStart | `/opt/lumisition/lumi-device-cloud/current/bin/lumi-device-cloud.py` |
| 配置 | `/etc/lumi/device-cloud.conf` |
| 状态 | `/run/lumi-device-cloud/status.json` |
| OTA 钩子 | **无**。只能 `systemctl`，不能当 application OTA 包 |

源码仓库名是 `lumisition_device_agent`，装出来却是 **cloud** 进程。局域网 Agent 在 [lumi-device-agent.md](lumi-device-agent.md)。

## 做什么 / 不做什么

做：出站连 DeviceOps（HTTPS/WSS）：心跳（启动时间、时长、`/opt` 各应用 VERSION、SN=`device_id`、可选 GPS）、日志上传、云端下发的 Web 终端。

不做：不替代 `:50052` OTA/自检；**不打开 `/dev/ttyS7`**；OTA 仍走 APP 中继 + Device Agent。

`Wants=lumi-device-agent.service` 但是弱依赖：Agent 没起来 cloud 仍可跑（密钥/device-id 可能不齐）。

## 日常操作

```bash
sudo systemctl enable --now lumi-device-cloud.service
sudo systemctl restart lumi-device-cloud.service
sudo systemctl stop lumi-device-cloud.service
systemctl is-active lumi-device-cloud.service
```

改 conf 后必须 restart。

本机 mock（仅开发联调，生产不要用）：

```bash
/opt/lumisition/lumi-device-cloud/current/bin/lumi-device-cloud-mock.py --port 8788
# conf 里 DEVICEOPS_BASE_URL=http://127.0.0.1:8788 后 restart 本服务
```

## 配置与状态

`/etc/lumi/device-cloud.conf`（重装不覆盖）：

| 项 | 含义 |
| --- | --- |
| `DEVICEOPS_BASE_URL` | 生产 `https://ota.lumisrobotics.com`；空则空闲、不连云 |
| `DEVICEOPS_CONNECT_HOST` | 源站 IP（TLS SNI 异常时的回退） |
| `DEVICE_ID_FILE` | `/etc/lumi/device-id` |
| `EVENT_PRIVATE_KEY` | 与 OTA 同一把 `event-ed25519-private.pem` |
| `GPS_FILE` | `/run/lumi-device-cloud/gps.json`（HAL `GetSensors()` 写入） |
| `MCU_FILE` | `/run/lumi-device-cloud/mcu.json`（可选） |
| `COMPONENTS_ROOT` | `/opt/lumisition` |
| `LOG_UNITS` | 默认含 Agent / cloud / internet |
| `SHELL_USER` | 默认 `lumisition` |

Webshell URL 由云端 `start_shell` 下发，不在 conf 里写死路径。

运行目录：`RuntimeDirectory=lumi-device-cloud`（`/run/lumi-device-cloud`，重启服务保留）。

## 依赖与互斥

- `After`：`network-online.target`、`lumi-device-agent-init.service`
- GPS 依赖 fanout/HAL 写 json，本进程不抢 `ttyS7`
- 出网依赖 [internet-service.md](internet-service.md) 或 STA；无 4G 时只要 Wi-Fi 能出网即可
- 与 Agent 共用 `device-id` 和事件私钥，职责不重叠

## 日志与检查

```bash
journalctl -u lumi-device-cloud.service -b -n 40 --no-pager
cat /run/lumi-device-cloud/status.json
ls -l /run/lumi-device-cloud/gps.json
cat /etc/lumi/device-id
```

## 不要做

- 不要 `systemctl restart lumi-device-agent` 来「重连云」。
- 不要为了 GPS 让本进程打开 `/dev/ttyS7`。
- 不要当 application OTA 组件（缺钩子）。
- 不要从 `~/git_repo/lumisition_device_agent` 当板上入口跑（日常用 `/opt/.../current`）。
