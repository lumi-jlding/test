# power-board-ota

清单：[index.md](index.md)

## 身份

| 项 | 值 |
| --- | --- |
| `/opt` 目录 | `/opt/lumisition/power-board-ota/current` |
| unit | `power-board-ota.service` |
| 类型 | oneshot **静态**（无 `[Install]`） |
| ExecStart | `/opt/lumisition/power-board-ota/current/bin/power-board-ota-run.sh` |
| 串口 | `/dev/ttyS7`，115200 8N1 |
| OTA 钩子 | 有；**`bin/start` 只校验 release，不刷 MCU**；`bin/stop` 为空操作 |

`systemctl is-enabled` 显示 `static` 是预期，不是安装失败。

## 做什么 / 不做什么

做：MCU 固件**已经在 RK 本地**之后，经 UART7 把 A/B 槽固件写入 STM32H743 Bootloader 并切槽验活。

不做：云端下载、验签、SCP；不开机自动刷。上传固件目录本身不会触发升级。

## 日常操作（必须按序）

**禁止** `systemctl enable power-board-ota.service`。

刷写前释放 fanout 占用的 `/dev/ttyS7`（loco 会随 fanout 停）：

```bash
sudo systemctl stop d1-hal-fanout.service
sudo fuser /dev/ttyS7 || echo 'ttyS7 free'
```

确认 `/etc/lumi/power-board-ota.conf` 里 `POWER_BOARD_OTA_FIRMWARE_DIR` 指向同时含这两个文件的目录：

- `three_power_board_app_slot_a.bin`
- `three_power_board_app_slot_b.bin`

然后**只 start 一次**：

```bash
sudo systemctl start power-board-ota.service
systemctl status power-board-ota.service --no-pager
```

成功或失败后 MCU 侧保持急停。检查通过再恢复：

```bash
sudo systemctl start d1-hal-fanout.service
sudo systemctl start lumi-locomotion.service   # 需要行走时
```

超时约 15 分钟。不要和 `power_board_cli` 同时开串口。

## 配置与状态

`/etc/lumi/power-board-ota.conf`（权限建议 `0600`）：

| 项 | 含义 |
| --- | --- |
| `POWER_BOARD_OTA_DEVICE` | 默认 `/dev/ttyS7` |
| `POWER_BOARD_OTA_BAUD` | `115200` |
| `POWER_BOARD_OTA_FIRMWARE_DIR` | **必填**，一对 bin 所在目录 |
| `POWER_BOARD_OTA_STATE_FILE` | `/var/lib/lumi/power-board-ota/last-run.state` |
| `POWER_BOARD_OTA_LOCK_FILE` | `/run/lock/lumi-power-board-ota.lock` |
| `POWER_BOARD_OTA_ACKNOWLEDGE_UNCERTAIN_APPLY` | 默认 `0`；仅人工确认不确定 APPLY 后短暂改 `1` |

Linux 允许多进程 `open` 同一 TTY，进程锁**拦不住** fanout。`0x82` / `0x83` 超时优先查 fanout 是否仍占串口。

## 依赖与互斥

- **与 `d1-hal-fanout.service` 互斥 `/dev/ttyS7`**
- 不占用 fanout 的 DDS / `:50051`；只是刷期间 HAL 遥测暂停
- cloud 的 GPS 文件由 HAL 写，cloud **不**打开 `ttyS7`

## 日志与检查

```bash
journalctl -u power-board-ota.service -b -n 80 --no-pager
cat /var/lib/lumi/power-board-ota/last-run.state
test -c /dev/ttyS7
```

## 不要做

- 不要 enable，不要放到 `WantedBy=multi-user.target`。
- 不要在 fanout active 时 start 本服务。
- 不要把 OTA 钩子 `bin/start` 当成「开始刷写」。
- 不要假设失败后能从上次 `0x83` offset 续传；重试仍须 `ttyS7` 空闲并开一整轮。
