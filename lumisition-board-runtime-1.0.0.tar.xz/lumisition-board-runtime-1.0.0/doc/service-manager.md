# service-manager

清单：[index.md](index.md)

## 身份

| 项 | 值 |
| --- | --- |
| `/opt` 目录 | `/opt/lumisition/service-manager/current` |
| 命令 | `/usr/local/bin/lumi-svc` → `current/bin/lumi-svc` |
| unit | **无**。这不是开机服务 |
| 配置 | `/etc/lumi/service-switch.yaml` |
| OTA 钩子 | **无**。不能当 application OTA 包 |

白名单决定能操作哪些 unit。未登记的 unit，包括 `power-board-ota.service`，不能通过本命令启停。

## 做什么 / 不做什么

做：对白名单服务执行 `start` / `stop` / `restart` / `enable` / `disable`，用 `apply` 一次打开列出的服务并关闭其余白名单服务，用 `logs` 看这些服务的 journal。

不做：不替代 systemd；不启停系统服务；不刷电源板 MCU；没有 Web 页面。

`start` / `stop` / `restart` 只影响本次运行。`enable` / `disable` 只影响下次开机。

## 日常操作

```bash
lumi-svc status
sudo lumi-svc stop avm
sudo lumi-svc disable avm
sudo lumi-svc start fanout
sudo lumi-svc restart fanout
sudo lumi-svc apply --preset field --yes
sudo lumi-svc apply --runtime fanout loco --yes
sudo lumi-svc logs fanout
sudo lumi-svc logs loco -f
sudo lumi-svc logs selfcheck --boot
```

`apply` 关闭未列出的服务时必须带 `--yes`，否则只打印计划。`--runtime` 只改本次运行，不改开机开关。

`logs` 默认最近 80 行，包含更早的开机记录。`--boot` 才限制本次开机。`-f` 持续跟踪，Ctrl+C 结束。读系统日志需要 root，或用户在 `adm` / `systemd-journal` 组。

预设：

| 预设 | 打开 |
| --- | --- |
| `field` | fanout、运控、BLE、Agent、出口、云通道、自检。不含环视 |
| `motion` | fanout、运控 |
| `bringup` | BLE、Agent、出口 |
| `avm` | `field` 再加环视 |

服务 id：`fanout`、`loco`、`ble`、`agent`、`cloud`、`internet`、`avm`、`selfcheck`。

## 依赖与互斥

- 运控的开机项挂在 fanout 上。`apply` 里要运控就必须带 fanout。
- 停 fanout 会连带停运控。`disable fanout` 不会 `disable` 运控，但下次开机运控不会把 fanout 拉起来。
- 自检是开机任务：`enable` / `disable` 决定下次开机跑不跑；`start` / `restart` 会立刻再跑。
- 电源板 OTA 不在白名单里。刷 MCU 仍按 [power-board-ota.md](power-board-ota.md)，先停 fanout。

## 配置

`/etc/lumi/service-switch.yaml`。重装不覆盖已有文件。改预设后执行 `lumi-svc --self-test`。

## 日志与检查

```bash
lumi-svc status
readlink -f /usr/local/bin/lumi-svc
readlink -f /opt/lumisition/service-manager/current
cat /opt/lumisition/service-manager/current/VERSION
```

`/usr/local/bin/lumi-svc` 应指向 `/opt/lumisition/service-manager/current/bin/lumi-svc`。

## 不要做

- 不要 `systemctl enable` 一个不存在的 `lumi-service-manager.service`。
- 不要把本命令当成业务进程的启动方式去代替各服务自己的 unit。
- 不要把 `power-board-ota` 写进白名单。
