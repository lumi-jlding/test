# lumi-device-agent

清单：[index.md](index.md)

## 身份

| 项 | 值 |
| --- | --- |
| `/opt` 目录 | `/opt/lumisition/lumi-device-agent/current` |
| 主 unit | `lumi-device-agent.service` |
| 初始化 | `lumi-device-agent-init.service`（静态 oneshot，由 Agent `Requires` 拉起） |
| 类型 | 常驻 `simple`；可 enable |
| ExecStart | `/opt/lumisition/lumi-device-agent/current/bin/lumi-device-agent-run.sh` |
| 监听 | `0.0.0.0:50052` — SelfCheck + OTA + Factory + **DeviceDiag（fanout 日志导出）** |
| OTA 钩子 | 有（本应用自升级也走安装器钩子） |

**不是** [lumi-device-cloud.md](lumi-device-cloud.md)。Agent 是局域网 gRPC；cloud 是出站 DeviceOps。

## 做什么 / 不做什么

做：板上唯一 `:50052`。APP 用 BLE 拿到的 `RK_IP:50052` 做 Ping、读自检、下发 application OTA、工厂模式，以及 **导出本次开机后的 fanout journal**（`lumi.diag.v1.DeviceDiagService`，见 `ota/doc/APP-fanout日志导出对接说明.md`）。身份与密钥由 init 写到 `/etc/lumi`。自检 JSON 在 RPC 时读取，不阻塞监听。

不做：实时 RobotService（`:50051` 是 fanout）；出站心跳/Web 终端（cloud）；不再提供独立 `check-gRPC-server`。

unit 仍 `Conflicts=check-gRPC-server.service`。源码已删该 unit；板上若残留，安装脚本会退役它且**不停** Agent。

## 日常操作

```bash
sudo systemctl enable --now lumi-device-agent.service
sudo systemctl restart lumi-device-agent.service
sudo systemctl stop lumi-device-agent.service
systemctl is-active lumi-device-agent.service lumi-device-agent-init.service
```

不要单独 enable init unit。停 Agent 不影响 BLE 与 `:50051`。

## 配置与状态

`EnvironmentFile=-/etc/lumi/device-agent/device-agent.env`（已有文件安装不覆盖）

| 项 | 典型路径 |
| --- | --- |
| 设备 ID | `/etc/lumi/device-id`（eth0 MAC，小写冒号） |
| 事件私钥 | `/etc/lumi/device-agent/keys/event-ed25519-private.pem` |
| 制品公钥 | `/etc/lumi/device-agent/keys/ota-artifact-release-ed25519-v1.pem` |
| HAL 报告 | `/var/lib/hal-selfcheck/report.json` |
| OS 报告 | `/var/lib/os-env-selfcheck/result.json` |
| OTA 状态 | `/var/lib/lumi-ota` |
| Agent 状态 | `/var/lib/lumi-device-agent` |

`ProtectHome=read-only`，`ReadWritePaths=/opt/lumisition`。业务文件不要放家目录。

## 依赖与互斥

- `Requires` init；`Wants` NetworkManager 与两项自检
- `RequiresMountsFor=/var/lib/hal-selfcheck` `/var/lib/os-env-selfcheck` `/opt/lumisition`
- `:50052` 只允许本进程
- application OTA 安装器会调各应用 `bin/start|stop|healthcheck`；internet / cloud **没有**这套钩子，不能当 OTA 组件

## 日志与检查

```bash
journalctl -u lumi-device-agent.service -u lumi-device-agent-init.service -b -n 80 --no-pager
ss -ltnp | grep ':50052'
cat /etc/lumi/device-id
cat /opt/lumisition/lumi-device-agent/current/VERSION
```

验收：`ss` 上 `:50052` 只有 `lumi-device-agent`。APP 应先 Ping 再轮询自检。

## 不要做

- 不要再 enable / 启动 `check-gRPC-server.service`。
- 不要把本服务和 `lumi-device-cloud.service` 当成同一个。
- 不要从 `/home/.../ota` 跑 Agent 二进制。
